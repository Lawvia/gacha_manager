# import the necessary packages
from sklearn.preprocessing import LabelEncoder
from sklearn import svm
import argparse
import pickle

# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-e", "--embeddings", required=True, help="path to serialized db of facial embeddings")
ap.add_argument("-r", "--recognizer", required=True, help="path to output model trained to recognize faces")
ap.add_argument("-l", "--le", required=True, help="path to output label encoder")
ap.add_argument("-c", "--cvalue", type=float, default=1.0, required=True, help="path to output label encoder")
args = vars(ap.parse_args())

# load the pickled embeddings
data = pickle.loads(open(args["embeddings"], "rb").read())

# encode the labels
le = LabelEncoder()
labels = le.fit_transform(data["names"])

print("Training model...")

# Create and train the SVC classifier
recognizer = svm.SVC(C=args["cvalue"],gamma='scale')
recognizer.fit(data["embeddings_prealigned"],labels)
print("Training completed...")
print(recognizer)
print(le.classes_)

# write the actual face recognition model to disk
f = open(args["recognizer"], "wb")
f.write(pickle.dumps(recognizer))
f.close()

# write the actual face recognition model to disk
f = open(args["le"], "wb")
f.write(pickle.dumps(le))
f.close()
# import the necessary packages
from imutils.video import VideoStream
from imutils.video import FPS
# import numpy as np
import argparse
# import imutils
import pickle
import time
import cv2
# import os
import face_recognition
import numpy as np
from datetime import datetime


# unknown = 0
# initSeconds = int(round(time.time() * 1000))
# resetSecs = 0 

# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-e", "--embeddings", required=True, help="path to embeddings")
ap.add_argument("-r", "--recognizer", required=True, help="path to model trained to recognize faces")
ap.add_argument("-l", "--le", required=True, help="path to label encoder")
ap.add_argument("-d", "--detection", type=str, default="hog", help="face detection model to use: either `hog` or `cnn`")
args = vars(ap.parse_args())


print("Loading face embeddings, recognition model and label encoder...")
# load the actual face recognition model along with the label encoder
embeddings = args["embeddings"]
recog = args["recognizer"]
label_encoder = args["le"]
data = pickle.loads(open(embeddings, "rb").read())
recognizer = pickle.loads(open(recog, "rb").read())
le = pickle.loads(open(label_encoder, "rb").read())


# initialize the video stream, then allow the camera sensor to warm up
print("Starting video stream...")
vs = cv2.VideoCapture(2)
vs.set(cv2.CAP_PROP_FRAME_WIDTH,1000);
vs.set(cv2.CAP_PROP_FRAME_HEIGHT,800);
# vs.set(cv2.CAP_PROP_FPS,30)

time.sleep(2.0)

# FPS throughput estimator
fps = FPS().start()


# Initialize variables
face_locations = []
face_encodings = []
face_names = []
process_frame = True

# loop over frames from the video file stream
while True:
    # grab each frame from the video stream
    ret, frame = vs.read()
    
    # resize frame of video to 1/4 size for faster face recognition processing
    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
    
    # convert the image from BGR color (OpenCV use BGR) to RGB color
    rgb_small_frame = small_frame[:, :, ::-1]
    
    # process every other frame of video to save time
    if process_frame:
        # detect all faces and face encodings in current frame
        face_locations = face_recognition.face_locations(rgb_small_frame, model=args["detection"])
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
        
        face_names = []
        for encoding in face_encodings:
            name = recognizer.predict([encoding])
            name_class = le.classes_[name][0]
            face_names.append(name_class)
            
#             # get min distance metrics; how far apart the current frame/faces from the known faces
#             face_distances = face_recognition.face_distance(data["embeddings"], encoding)
#             min_face_distance = face_distances[np.argmin(face_distances)]
            
#             text = "{}-{:.2f}".format(le.classes_[name][0], min_face_distances)

    process_frame = not process_frame
    
    # show the results
    for (top, right, bottom, left), name in zip(face_locations, face_names):
        # scale back up face locations since it was scaled to 1/4 size before
        top *= 4
        right *= 4
        bottom *= 4
        left *= 4
        
        # insert datetime info
        font_dt = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(frame,str(datetime.now()),(10,30), font_dt, 0.5,(0,255,255),2,cv2.LINE_AA)

        # draw rectangle around the face
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
    
        # give label with a name below the face
        cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 255, 0), cv2.FILLED)
        
        # insert custom text and font
        font = cv2.FONT_HERSHEY_DUPLEX
#         text = "{}-{:.2f}".format(name, min_face_distance)
        text = "{}".format(name)
        cv2.putText(frame, text, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)
    
    # update FPS counter
    fps.update()


    # display the image/video
    cv2.imshow('Video Inference', frame)

    # Press 'q' on the keyboard to quit!
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# stop the timer and display FPS information
fps.stop()
print("Elasped time: {:.2f}".format(fps.elapsed()))
print("Approx. FPS: {:.2f}".format(fps.fps()))

# release camera/webcam handle
vs.release()
cv2.destroyAllWindows()

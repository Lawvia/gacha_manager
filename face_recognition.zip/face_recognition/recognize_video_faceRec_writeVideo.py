# write video to disk

# import the necessary packages
from imutils.video import VideoStream
from imutils.video import FPS
# import numpy as np
import argparse
import imutils
import pickle
# import time
import cv2
# import os
import face_recognition
import numpy as np

# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-i", "--input", required=True, help="path to input")
ap.add_argument("-o", "--output", required=True, help="path to output")
ap.add_argument("-y", "--display", type=int, default=1, help="whether or not to display output frame to screen")
ap.add_argument("-e", "--embeddings", required=True, help="path to embeddings")
ap.add_argument("-r", "--recognizer", required=True, help="path to model trained to recognize faces")
ap.add_argument("-l", "--le", required=True, help="path to label encoder")
ap.add_argument("-d", "--detection", type=str, default="hog", help="face detection model to use: either `hog` or `cnn`")
args = vars(ap.parse_args())


print("Loading face embeddings, recognition model and label encoder...")
# load the actual face recognition model along with the label encoder
embeddings = args["embeddings"]
recog = args["recognizer"]
label_encoder = args["le"]
data = pickle.loads(open(embeddings, "rb").read())
recognizer = pickle.loads(open(recog, "rb").read())
le = pickle.loads(open(label_encoder, "rb").read())


# initialize the video stream, then allow the camera sensor to warm up
print("Starting video stream...")
vs = cv2.VideoCapture(args["input"])
writer = None

# Initialize variables
face_locations = []
face_encodings = []
face_names = []
# process_this_frame = True

# loop over frames from the video file stream
while True:
    # grab the frame from the threaded video stream
    ret, frame = vs.read()
    
    # Quit when the input video file ends
    if not ret:
        break
        
    # Convert the image from BGR color (which OpenCV uses) to RGB color (which face_recognition uses)
    rgb_frame = frame[:, :, ::-1]
    
    # Find all the faces and face encodings in the current frame
    face_locations = face_recognition.face_locations(rgb_frame, model=args["detection"])
    face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)
        
    face_names = []
    for face_encoding in face_encodings:
        name = recognizer.predict([face_encoding])
        name_class = le.classes_[name][0]
        face_names.append(name_class)
        
# Get min distance metrics; how far apart the current frame/faces from the known faces

#         face_distances = face_recognition.face_distance(data["embeddings"], face_encoding)
#         min_face_distances = face_distances[np.argmin(face_distances)]
        
#         text = "{}-{:.2f}".format(name_class, min_face_distances)

    # Display the results
    for (top, right, bottom, left), name in zip(face_locations, face_names):
        # Draw a box around the face
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)

        # Put label with a name below the face
#         cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
        y = top - 15 if top - 15 > 15 else top + 15
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(frame, name, (left, y), font, 0.45, (255, 255, 255), 1)

    if writer is None and args["output"] is not None:
        fourcc = cv2.VideoWriter_fourcc(*"MJPG")
        writer = cv2.VideoWriter(args["output"], fourcc, 20, (frame.shape[1], frame.shape[0]), True)


    if writer is not None:
        writer.write(frame)


    if args["display"] > 0:
        cv2.imshow("Frame", frame)
        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            break


cv2.destroyAllWindows()
# vs.stop()

if writer is not None:
    writer.release()